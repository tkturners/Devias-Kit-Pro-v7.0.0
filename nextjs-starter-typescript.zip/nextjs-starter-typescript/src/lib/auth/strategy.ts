export const AuthStrategy = {
  CUSTOM: 'CUSTOM',
} as const;
