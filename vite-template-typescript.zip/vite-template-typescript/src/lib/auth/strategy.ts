export const AuthStrategy = {
  CUSTOM: 'CUSTOM',
  AUTH0: 'AUTH0',
  COGNITO: 'COGNITO',
  FIREBASE: 'FIREBASE',
  SUPABASE: 'SUPABASE',
} as const;
