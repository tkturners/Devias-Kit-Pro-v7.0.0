export const MuiStack = { defaultProps: { useFlexGap: true } };
