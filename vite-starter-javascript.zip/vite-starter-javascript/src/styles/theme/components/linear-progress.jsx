export const MuiLinearProgress = {
  styleOverrides: { root: { borderRadius: '8px', overflow: 'hidden' } },
};
