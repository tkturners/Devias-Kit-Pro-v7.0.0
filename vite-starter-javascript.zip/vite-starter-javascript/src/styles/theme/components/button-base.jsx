export const MuiButtonBase = { defaultProps: { disableRipple: true } };
