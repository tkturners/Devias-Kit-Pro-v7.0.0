export const MuiPaper = {
  styleOverrides: { root: { backgroundImage: 'none' } },
};
