export const MuiInputLabel = {
  styleOverrides: { root: { maxWidth: '100%', position: 'static', transform: 'none' } },
};
