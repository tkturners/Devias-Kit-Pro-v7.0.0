export const MuiFormGroup = { styleOverrides: { root: { gap: '16px' } } };
