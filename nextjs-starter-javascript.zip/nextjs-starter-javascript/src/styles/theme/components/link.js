export const MuiLink = { defaultProps: { underline: 'hover' } };
