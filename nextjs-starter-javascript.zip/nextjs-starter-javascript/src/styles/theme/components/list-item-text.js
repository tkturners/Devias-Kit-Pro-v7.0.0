export const MuiListItemText = {
  styleOverrides: { root: { margin: 0 } },
};
