export const MuiAlert = { styleOverrides: { message: { fontWeight: 500 } } };
