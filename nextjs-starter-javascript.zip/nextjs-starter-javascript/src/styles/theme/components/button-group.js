export const MuiButtonGroup = { defaultProps: { disableRipple: true } };
