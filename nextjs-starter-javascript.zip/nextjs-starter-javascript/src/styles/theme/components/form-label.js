export const MuiFormLabel = {
  styleOverrides: { root: { color: 'var(--mui-palette-text-primary)', fontSize: '0.875rem', fontWeight: 500 } },
};
