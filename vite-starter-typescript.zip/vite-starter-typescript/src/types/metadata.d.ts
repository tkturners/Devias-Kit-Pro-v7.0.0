export interface Metadata {
  title?: string;
  description?: string;
}
